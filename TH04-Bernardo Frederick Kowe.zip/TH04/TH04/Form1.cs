﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace TH04
{
    public partial class Form1 : Form
    {
        List<string> country = new List<string>();
        List<string> pemain = new List<string>();
        
        public Form1()
        {
            InitializeComponent();
        }
        DataTable nama = new DataTable();
        DataTable Bola = new DataTable();
        DataTable no = new DataTable();
        int a;
        private void Form1_Load(object sender, EventArgs e)
        {
            MessageBox.Show(nama_pemain.Top.ToString() + "  " + no_punggung.Top.ToString() + " " + nama_pemain.Left.ToString());
            box_posisi.Top = 102;
            box_posisi.Left = 528;
            string[] MC = { "(18) Stefan Ortega, GK", "(3) Ruben Dias, DF", 
                "(5) John Stones, DF", "(21) Sergio Gomez, DF", 
                "(25) Manuel Akanji, DF", "(20) Bernardo Silva, MF", 
                "(27) Matheus Nunes, MF", "(47) Phil Foden, MF", 
                "(9) Erling Haaland, FW", "(11) Jeremy Doku, FW", "(19) Julian Alvarez, FW"};
            string[] Bar = {"(13) Inaki Pena, GK", "(2) Joalo Cancelo, DF",
                "(3) Alejandro Balde, DF", "(4) Ronald Araujo, DF",
                "(20) Sergi Roberto, DF", "(6) Gavi, MF",
                "(18) Oriol Romeu, MF", "(21) Frenkie de Jong, MF",
                "(11) Raphinha, FW", "(14) Joao Felix, FW", "(27) Lamine Yamal, FW"};
            string[] RM = {"(13) Andriy Lunin, GK", "(2) Dani Carvajal, DF",
                "(22) Antonio Rudiger, DF", "(20) Fran Garcia, DF",
                "(23) Ferland Mendy, DF", "(5) Jude Belingham, MF",
                "(8) Toni Kroos, MF", "(10) Luka Modric, MF",
                "(7) Vinicius Junior, FW", "(11) Rodrygo, FW", "(14) Joselu, FW"};

            string[] MU = { "18", "3", "5", "21", "25", "20", "27", "47", "9", "11", "19" };
            string[] Ba = { "13", "2", "3", "4", "20", "6", "18", "21", "11", "14", "27" };
            string[] Re = { "13", "2", "22", "20", "23", "5", "8", "10", "7", "11", "14" };

            string[] MCity = { "Stefan Ortega", "Ruben Dias", "John Stones", "Sergio Gomez", 
                "Manuel Akanji", "Bernardo Silva", "Matheus Nunes", "Phil Foden", "Erling Haaland", 
                "Jeremy Doku", "Julian Alvarez"};
            string[] Barca = {"Inaki Pena", "Joalo Cancelo",
                "Alejandro Balde", "Ronald Araujo",
                "Sergi Roberto", "Gavi",
                "Oriol Romeu", "Frenkie de Jong",
                "Raphinha", "Joao Felix", "Lamine Yamal"};
            string[] Real = {"Andriy Lunin", "Dani Carvajal",
                "Antonio Rudiger", "Fran Garcia",
                "Ferland Mendy", "Jude Belingham",
                "Toni Kroos", "Luka Modric",
                "Vinicius Junior", "Rodrygo", "Joselu"};

            nama.Columns.Add("Manchester United");
            nama.Columns.Add("Barcelona");
            nama.Columns.Add("Real Madrid");

            for (int i = 0; i < MCity.Length; i++)
            {
                nama.Rows.Add();
                nama.Rows[i][0] = MCity[i];
            }
            for (int i = 0; i < Barca.Length; i++)
            {
                nama.Rows[i][1] = Barca[i];
            }
            for (int i = 0; i < Real.Length; i++)
            {
                nama.Rows[i][2] = Real[i];
            }

            no.Columns.Add("Manchester United");
            no.Columns.Add("Barcelona");
            no.Columns.Add("Real");

            for (int i = 0; i < MU.Length; i++)
            {
                no.Rows.Add();
                no.Rows[i][0] = MU[i];
            }
            for (int i = 0; i < Ba.Length; i++)
            {
                no.Rows[i][1] = Ba[i];
            }
            for (int i = 0; i < Re.Length; i++)
            {
                no.Rows[i][2] = Re[i];
            }

            country.Add("England");
            country.Add("Italy");


            box_country.Items.Add(country[0]);
            box_country.Items.Add(country[1]);

            Bola.Columns.Add("Manchester United");
            Bola.Columns.Add("Barcelona");
            Bola.Columns.Add("Real Madrid");
            Bola.Rows.Add(0, 0, 1);

            for (int i = 0; i < MC.Length; i++)
            {
                Bola.Rows.Add();
                Bola.Rows[i + 1][0] = MC[i];
            }
            for (int i = 0; i < Bar.Length; i++)
            {
                Bola.Rows[i + 1][1] = Bar[i];
            }
            for (int i = 0; i < RM.Length; i++)
            {
                Bola.Rows[i + 1][2] = RM[i];
            }
        }

        private void add_team_Click(object sender, EventArgs e)
        {
            int tes = 0;
            if (add_name.Text == "" || add_country.Text == "" || add_city.Text == "")
            {
                DialogResult mb = MessageBox.Show("All Fields Need to be Filled ❤️❤️❤️", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                bool k = true;
                for (int j = 0; j < Bola.Columns.Count; j++)
                {
                    if (Bola.Columns[j].ColumnName == add_name.Text)
                    {
                        k = false;
                        DialogResult mb = MessageBox.Show("Team with Same Name is Found ❤️❤️❤️", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        break;
                    }
                }
                if (k == false)
                {
                    k = true;
                }
                else
                {
                    for (int i = 0; i < country.Count; i++)
                    {
                        if (country[i] == add_country.Text)
                        {
                            a = i;
                            Bola.Columns.Add(add_name.Text);
                            nama.Columns.Add(add_name.Text);
                            no.Columns.Add(add_name.Text);
                            Bola.Rows[0][Bola.Columns.Count - 1] = a;
                            break;
                        }
                        else
                        {
                            tes++;
                            if (tes == country.Count)
                            {
                                int test = 0;
                                a = country.Count;
                                country.Add(add_country.Text);
                                box_country.Items.Add(add_country.Text);
                                Bola.Columns.Add(add_name.Text);
                                nama.Columns.Add(add_name.Text);
                                no.Columns.Add(add_name.Text);
                                Bola.Rows[0][Bola.Columns.Count - 1] = a;
                                a = 0;
                                break;
                            }
                        }
                    }
                }
            }
            add_city.Text = "";
            add_country.Text = "";
            add_name.Text = "";
            box_country.Text = "";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (box_country.Text != "" && box_team.Text != "" && box_posisi.Text != "" && nama_pemain.Text != "" && no_punggung.Text != "")
            {
                bool bul = false;
                int list = lb_pemain.Items.Count;
                int ha = 0;
                for (int i = 0; i < Bola.Columns.Count; i++)
                {
                    if (Bola.Columns[i].ColumnName == box_team.SelectedItem)
                    {
                        ha = i; break;
                    }
                }
                string name = "(" + no_punggung.Text + ") " + nama_pemain.Text + ", " + box_posisi.Text;
                for (int i = 0; i < nama.Columns.Count; i++)
                {
                    if (box_team.SelectedItem.ToString() == nama.Columns[i].ColumnName)
                    {
                        for (int j = 0; j < nama.Rows.Count; j++)
                        {
                            if (nama_pemain.Text.ToString() == nama.Rows[j][i].ToString())
                            {
                                DialogResult mb = MessageBox.Show("Player with Same Name is Found ❤️❤️❤️", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                bul = true;
                            }
                        }
                    }
                }
                for (int i = 0; i < no.Columns.Count; i++)
                {
                    if (box_team.SelectedItem.ToString() == no.Columns[i].ColumnName)
                    {
                        for (int j = 0; j < no.Rows.Count; j++)
                        {
                            if (no_punggung.Text.ToString() == no.Rows[j][i].ToString())
                            {
                                DialogResult mb = MessageBox.Show("Player with Same Number is Found ❤️❤️❤️", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                bul = true;
                            }
                        }
                    }
                }
                if (bul != true)
                {
                    Bola.Rows.Add();
                    nama.Rows.Add();
                    no.Rows.Add();

                    Bola.Rows[Bola.Rows.Count - 1][ha] = name;
                    nama.Rows[nama.Rows.Count - 1][ha] = nama_pemain.Text;
                    no.Rows[no.Rows.Count - 1][ha] = no_punggung.Text;

                    lb_pemain.Items.Clear();
                    for (int i = 1; i < Bola.Rows.Count; i++)
                    {
                        if (Bola.Rows[i][ha].ToString() != "")
                        {
                            lb_pemain.Items.Add(Bola.Rows[i][ha].ToString());

                        }
                    }

                    nama_pemain.Text = "";
                    no_punggung.Text = "";
                    box_posisi.Text = "";
                }
                else
                {
                    nama_pemain.Text = "";
                    no_punggung.Text = "";
                    box_posisi.Text = "";
                }
            }
            else
            {
                DialogResult mb = MessageBox.Show("All Fields Need to be Filled ❤️❤️❤️", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void box_country_SelectedIndexChanged(object sender, EventArgs e)
        {
            box_team.Items.Clear();
            
            for (int i = 0; i < country.Count; i++)
            {
                if (country[i] == box_country.SelectedItem.ToString())
                {
                    a = i;
                }
            }

            for (int i = 0; i < Bola.Columns.Count; i++)
            {
                if (a.ToString() == Bola.Rows[0][i].ToString())
                {
                    box_team.Items.Add(Bola.Columns[i].ColumnName);
                }
            }
        }

        private void box_team_SelectedIndexChanged(object sender, EventArgs e)
        {
            lb_pemain.Items.Clear();
            for (int i = 0; i < Bola.Columns.Count; i++)
            {
                if (box_team.SelectedItem == Bola.Columns[i].ColumnName)
                {
                    a = i;
                }
            }
            for (int i = 1; i < Bola.Rows.Count; i++)
            {
                if (Bola.Rows[i][a].ToString() != "")
                {
                    lb_pemain.Items.Add(Bola.Rows[i][a].ToString());
                }
            }
        }

        private void remove_Click(object sender, EventArgs e)
        {
            if (lb_pemain.SelectedItem == null)
            {
                
            }
            else
            {
                if (lb_pemain.Items.Count <= 11)
                {
                    DialogResult mb = MessageBox.Show("Unable to Remove Players if Players less than equal 11","Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
                }
                else
                {
                    int b = 0; ;
                    for (int i = 0;i < Bola.Columns.Count; i++)
                    {
                        if (Bola.Columns[i].ColumnName == box_team.SelectedItem)
                        {
                            b = i;
                            break;
                        }
                    }
                    for (int j = 1; j < Bola.Rows.Count; j++)
                    {
                        if (Bola.Rows[j][b].ToString() == lb_pemain.SelectedItem)
                        {
                            Bola.Rows[j][b] = "";
                            no.Rows[j - 1][b] = "";
                            nama.Rows[j - 1][b] = "";
                        }
                    }
                    lb_pemain.Items.Clear();
                    for (int i = 1; i < Bola.Rows.Count; i++)
                    {
                        if (Bola.Rows[i][b].ToString() != "")
                        {
                            lb_pemain.Items.Add(Bola.Rows[i][b].ToString());
                        }
                    }
                }
            }
        }
    }
}